package com.nameless.pet;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(40,70,40,30);
 TextView t=new TextView(this);t.setText("无名 · 像素桌宠 v0.1\n\n授权悬浮窗后点击启动。点击宠物会切换动作，长按可拖动。\n\n提示：部分系统可能在后台关闭服务。");t.setTextSize(19);l.addView(t);
 Button start=new Button(this);start.setText("启动无名");l.addView(start);start.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}else{startService(new Intent(this,PetService.class));Toast.makeText(this,"无名出现了",Toast.LENGTH_SHORT).show();}});
 Button stop=new Button(this);stop.setText("收起无名");l.addView(stop);stop.setOnClickListener(v->stopService(new Intent(this,PetService.class)));setContentView(l); }
}
