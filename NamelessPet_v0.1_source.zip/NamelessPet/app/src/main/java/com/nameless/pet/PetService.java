package com.nameless.pet;
import android.app.Service;import android.content.Intent;import android.graphics.*;import android.os.*;import android.view.*;
public class PetService extends Service {
 WindowManager wm;WindowManager.LayoutParams params;PetView pet;Handler h=new Handler(Looper.getMainLooper());int tick=0;boolean walking=false;
 final Runnable anim=new Runnable(){public void run(){if(pet!=null){tick++;pet.invalidate();h.postDelayed(this,220);}}};
 @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);params=new WindowManager.LayoutParams(210,240,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=80;params.y=300;pet=new PetView();wm.addView(pet,params);h.post(anim);}
 @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
 @Override public void onDestroy(){h.removeCallbacksAndMessages(null);if(pet!=null){wm.removeView(pet);pet=null;}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
 class PetView extends View {Bitmap[] idle=new Bitmap[6],right=new Bitmap[8],left=new Bitmap[8];float downX,downY;int origX,origY;boolean moved=false;long downTime;
 PetView(){super(PetService.this);try{for(int i=0;i<6;i++)idle[i]=load("idle_"+i);for(int i=0;i<8;i++){right[i]=load("walkR_"+i);left[i]=load("walkL_"+i);}}catch(Exception e){}setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 Bitmap load(String name)throws Exception{java.io.InputStream in=getAssets().open(name+".png");Bitmap b=BitmapFactory.decodeStream(in);in.close();return b;}
 @Override protected void onDraw(Canvas c){super.onDraw(c);Bitmap[] seq=walking?right:idle;Bitmap b=seq[tick%seq.length];if(b!=null){Paint p=new Paint();p.setFilterBitmap(false);c.drawBitmap(b,null,new Rect(0,0,getWidth(),getHeight()),p);}}
 @Override public boolean onTouchEvent(android.view.MotionEvent e){switch(e.getActionMasked()){
 case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();origX=params.x;origY=params.y;moved=false;downTime=System.currentTimeMillis();return true;
 case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-downX,dy=e.getRawY()-downY;if(Math.abs(dx)+Math.abs(dy)>12)moved=true;if(moved){params.x=origX+(int)dx;params.y=origY+(int)dy;wm.updateViewLayout(this,params);}return true;
 case MotionEvent.ACTION_UP:if(!moved){walking=!walking;tick=0;invalidate();}return true;
 }return true;}
 }
}
